// Raccourcis du tableau de bord. Les actions admin ne s'affichent qu'aux ADMIN.
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function QuickActions() {
  const { isAdmin } = useAuth();

  const actions = [
    { to: '/entreprises', label: 'Parcourir le répertoire', icon: '🏢' },
    ...(isAdmin
      ? [
          { to: '/entreprises/nouveau', label: 'Ajouter une entreprise', icon: '＋' },
          { to: '/admin/import', label: 'Importer un CSV', icon: '⬆' },
        ]
      : []),
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {actions.map((a) => (
        <Link
          key={a.to}
          to={a.to}
          className="flex items-center gap-3 bg-white rounded-xl shadow p-4 hover:bg-elikia-light transition"
        >
          <span className="w-10 h-10 rounded-full bg-elikia text-white flex items-center justify-center">
            {a.icon}
          </span>
          <span className="font-medium text-ink">{a.label}</span>
        </Link>
      ))}
    </div>
  );
}
